module.exports = {
  root: true,
  parser: "@typescript-eslint/parser",
  plugins: [
    "@typescript-eslint"
  ],
  extends: [
    "eslint:recommended",
    "plugin:@typescript-eslint/eslint-recommended",
    "plugin:@typescript-eslint/recommended"
  ],
  rules: {
    "indent": [
      "off",
      2
    ],
    "quotes": [
      "error",
      "single"
    ],
    "semi": [
      "warn",
      "always"
    ],
    "comma-dangle": [
      "warn",
      "only-multiline"
    ],
    "func-style": [
      "warn",
      "declaration"
    ],
    "func-names": [
      "off",
      "as-needed"
    ],
    "no-unused-vars": [
      "warn",
      {
        vars: "all",
        args: "after-used",
        ignoreRestSiblings: false
      }
    ],
    "no-var": "error",
    "eqeqeq": "error",
    "no-eval": "error",
    "@typescript-eslint/no-inferrable-types": "off"
  }
}

Projektabgabe Teil 3 erstellt von Bela Bothin und Lukas Radermacher

Fetch error ist zu ignorieren da das JavaScript im Browser ausgeführt wird, es in der Node Umgebung aber als Fehler erkannt wird.

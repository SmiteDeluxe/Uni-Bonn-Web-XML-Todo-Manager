import { createApp } from 'vue';
import App from './App.vue';

createApp(App).mount('#app');

// Abgabe von Lukas Radermacher und Bela Bothin
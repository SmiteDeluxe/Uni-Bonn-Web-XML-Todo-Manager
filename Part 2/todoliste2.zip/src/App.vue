<template>
    <!-- Abgabe von Lukas Radermacher und Bela Bothin-->
    <Header v-bind:user_id="todolistdata[0].userID" v-bind:user_name="todolistdata[0].user"/>
    <Main v-bind:todolist="todolistdata[0]" @addnew="addnew" @addtask="addtask" @confirm_deletion_pressed="confirm_deletion_pressed" @calc_new_percent="calc_new_percent" @confirmchange_name="confirmchange_name" @confirmchange_date="confirmchange_date" @change_title="change_title" @deltask="deltask"/>
    <Footer/>
</template>

<script>
import Header from './components/Header.vue';
import Footer from './components/Footer.vue';
import Main from './components/Main_cont.vue';
import static_todolistdata from './static_todolistdata.js';


export default {
  name: 'App',
  components: {
    Header,
    Main,
    Footer
  },
  methods: {
    //Add a complete new taskwindow
    addnew: function(name) {
      let newitem = {
        name: name,
        listID: Math.floor(Math.random() * 14000000), //Gleiche Id unwahrscheinlicher als lotto gewinn (für jetzt)
        items: []
      };
      this.todolistdata[0].lists.push(newitem);
    },
    //Add the changed tasklist 
    addtask: function(newlistobj) {
        for(let i=0;i<this.todolistdata[0].lists.length;i++) {
            if(this.todolistdata[0].lists[i].listID === newlistobj.id) {
                this.todolistdata[0].lists[i].items.push(newlistobj.new);
            }
        }
    },
    confirm_deletion_pressed: function(id) {
        this.todolistdata[0].lists = this.todolistdata[0].lists.filter(e => e.listID !== id);
    },
    calc_new_percent: function(id){
        for(let i=0;i<this.todolistdata[0].lists.length;i++) {
            for(let j=0;j<this.todolistdata[0].lists[i].items.length;j++) {
                if(this.todolistdata[0].lists[i].items[j].taskID === id) {
                    this.todolistdata[0].lists[i].items[j].done = !(this.todolistdata[0].lists[i].items[j].done);
                }
            }
        }
    },
    confirmchange_name: function(task) {
        for(let i=0;i<this.todolistdata[0].lists.length;i++) {
            for(let j=0;j<this.todolistdata[0].lists[i].items.length;j++) {
                if(this.todolistdata[0].lists[i].items[j].taskID === task.id) {
                    this.todolistdata[0].lists[i].items[j].name = task.new;
                }
            }
        }
    },
    confirmchange_date: function(task) {
        for(let i=0;i<this.todolistdata[0].lists.length;i++) {
            for(let j=0;j<this.todolistdata[0].lists[i].items.length;j++) {
                if(this.todolistdata[0].lists[i].items[j].taskID === task.id) {
                    this.todolistdata[0].lists[i].items[j].deadline = task.new;
                }
            }
        }
    },
    change_title: function(titleobj) {
        for(let i=0;i<this.todolistdata[0].lists.length;i++) {
            if(this.todolistdata[0].lists[i].listID === titleobj.id) {
                this.todolistdata[0].lists[i].name = titleobj.new;
            }
        }
    },
    deltask: function(taskid) {
        for(let i=0;i<this.todolistdata[0].lists.length;i++) {
            for(let j=0;j<this.todolistdata[0].lists[i].items.length;j++) {
                let topop = this.todolistdata[0].lists[i].items[j];
                if(topop.taskID === taskid) {
                    this.todolistdata[0].lists[i].items.splice(j, 1);
                }
            }
        }
    }
  },
  data: function() {
    return {
      todolistdata: static_todolistdata,
    };
  },
};
</script>

<style>

html, body {
    height: 100%;
}
body {
    font-size: 17px;
    padding: 0;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color:rgb(255, 255, 255);
}
.color1 {
    background-color: #E77B73;
}
.color2 {
    background-color: #8799C0;
}
.color3 {
    background-color: #DEED5A;
}
.color4 {
    background-color: #9272AC;
}
.color5 {
    background-color: #FFD333;
}
.color6 {
    background-color: #E0BD52;
}
.color7 {
    background-color: #57B2C7;
}
.color8 {
    background-color: #B05782;
}
.color9 {
    background-color: #FF9747;
}
.color_main {
    color: rgb(32, 32, 32);
}

.unselectable {
    -webkit-user-select: none; /* Safari */        
    -moz-user-select: none; /* Firefox */
    -ms-user-select: none; /* IE10+/Edge */
    user-select: none; /* Standard */
}


#app {
    min-width: 800px;
    width: 65%;
    height: 80vh;
    border-radius: 10px;
    overflow: hidden;
    display: grid;
    grid-template-rows: 10% 80% 10%;
    grid-template-areas:
        "header"
        "main"
        "footer";
    box-shadow: 2px 2px 24px -8px rgba(0,0,0,0.4);
}

* { 
    -moz-box-sizing: border-box; 
    -webkit-box-sizing: border-box; 
    box-sizing: border-box; 
    color:rgb(32, 32, 32);
    font-family: 'Raleway', sans-serif;
}

/*Scrollbars*/
*::-webkit-scrollbar-track {
	border-radius: 10px;
}

*::-webkit-scrollbar {
	width: 12px;
}

* {
    scrollbar-color: rgb(231, 231, 231) transparent ;
    scrollbar-width: thin;
}

#div_scroll::-webkit-scrollbar-thumb{
	border-radius: 10px;
	background-color: rgb(231, 231, 231);
}

.upcoming_wrapper::-webkit-scrollbar-thumb{
	border-radius: 10px;
	background-color: rgb(248, 248, 248);
}

.big_task ul::-webkit-scrollbar-thumb {
	border-radius: 10px;
	background-color: rgb(223, 223, 223);
}


.btn {
    border-radius: 5px;
    border: 0px;
    margin: 2.5px 2.5px 2.5px 2.5px;
    height: 45px;
    width: 90px;
    cursor: pointer;
    font-weight: 500;
    font-size: 17px;
}

/* Media Stuff */
@media screen and (max-width: 675px) {
    #app {
        height: auto;
    }
}

@media screen and (orientation: landscape) and (max-height: 700px) {
    body{
        height: 100vh;
    }

    footer {
        display: none;
    }

    #app {
        grid-template-rows: 20% 80%;
        width: 100vw;
        height: 100vh;
        min-width: 0;
    }
}

@media screen and (max-width: 1025px) {
    #app {
        width: 100vw;
        height: 100vh;
        min-width: 0;
    }
}


@media  screen and (orientation: portrait) and (max-width: 675px) {
    
    #app{
        grid-template-rows: 10% 83% 7%;
    }

}

@media screen and (min-height:2160px){
    *{font-size: 35px;}
}

</style>

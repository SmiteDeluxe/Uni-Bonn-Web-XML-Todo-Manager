module.exports = {
  env: {
    node: true,
    es6: true,
    es2020: true
  },
  parserOptions: {
    parser: 'babel-eslint'
  },

  globals: {
    Atomics: "readonly",
    SharedArrayBuffer: "readonly"
  },

  rules: {
    "indent": [
      "off",
      2
    ],
    "quotes": [
      "off",
      "single"
    ],
    semi: [
      "warn",
      "always"
    ],
    "comma-dangle": [
      "warn",
      "only-multiline"
    ],
    "func-style": [
      "warn",
      "declaration"
    ],
    "func-names": [
      "warn",
      "as-needed"
    ],
    "no-unused-vars": [
      "warn",
      {
        vars: "all",
        args: "after-used",
        ignoreRestSiblings: false
      }
    ],
    "no-var": "error",
    "eqeqeq": "error",
    "no-eval": "error",
  },

  'extends': [
    'eslint:recommended',
    'plugin:vue/vue3-essential',
  ]
};

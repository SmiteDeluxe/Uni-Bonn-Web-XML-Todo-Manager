# Client-Vorlage für Aufgabe 2 des Programmierprojektes

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

## Erstellung dieser Vorlage
Diese Vorlage wurde mit der _vue-cli_ erstellt. Dafür wurde die Standardkonfiguration von VueJs 3 verwendet. Anschließend wurde nur die Datei `static_todolistdata.js` hinzugefügt und die Datei `App.vue` angepasst.
